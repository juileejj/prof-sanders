package com.nadasanders.nadasanders;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NadasandersApplication {

	public static void main(String[] args) {
		SpringApplication.run(NadasandersApplication.class, args);
	}
}
